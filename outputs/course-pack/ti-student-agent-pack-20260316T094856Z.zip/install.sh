#!/usr/bin/env bash
# TI Student Agent Pack Installer
# Quick install: curl -sL https://raw.githubusercontent.com/finnoh/ti-student-agent-pack/main/install.sh | bash
# Or download the zip and run: chmod +x install.sh && ./install.sh

set -euo pipefail

echo "=== TI Student Agent Pack Installer ==="

# Extract the zip file
if [ -f "student-agent-pack.zip" ]; then
    echo "Extracting student-agent-pack.zip..."
    unzip -q student-agent-pack.zip
elif [ -d "student-agent-pack" ]; then
    echo "Using existing student-agent-pack directory..."
else
    echo "Error: Could not find student-agent-pack directory or zip file"
    exit 1
fi

# Run the actual install script
if [ -f "student-agent-pack/install.sh" ]; then
    cd student-agent-pack
    ./install.sh
else
    echo "Error: install.sh not found in student-agent-pack"
    exit 1
fi
