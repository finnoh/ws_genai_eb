#!/usr/bin/env bash
# TI Student Agent Pack Installer
# Works on Linux, macOS, and Windows (via Git Bash/WSL)
#
# Usage:
#   curl -sL https://raw.githubusercontent.com/finnoh/ti-student-agent-pack/main/install.sh | bash
#   # OR locally after downloading zip:
#   chmod +x install.sh && ./install.sh
#
# This script:
# 1. Detects the OS and architecture
# 2. Installs Python if needed (or checks for existing installation)
# 3. Sets up the student-agent-pack directory structure
# 4. Initializes exercise files
# 5. Runs startup checks

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print functions
print_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Detect OS
detect_os() {
    case "$(uname -s)" in
        Linux*)     OS="linux" ;;
        Darwin*)    OS="macos" ;;
        CYGWIN*|MINGW*|MSYS*) OS="windows" ;;
        *)          OS="unknown" ;;
    esac

    # Detect architecture
    ARCH=$(uname -m)
    case "$ARCH" in
        x86_64) ARCH="x64" ;;
        aarch64|arm64) ARCH="arm64" ;;
        *) ARCH="unknown" ;;
    esac

    print_info "Detected OS: $OS ($ARCH)"
}

# Check Python installation
check_python() {
    print_info "Checking Python installation..."

    if command -v python3 &> /dev/null; then
        PYTHON_CMD="python3"
        PYTHON_VERSION=$(python3 -V 2>&1 | cut -d' ' -f2)
        print_info "Found Python $PYTHON_VERSION"
        return 0
    elif command -v python &> /dev/null; then
        PYTHON_CMD="python"
        PYTHON_VERSION=$(python -V 2>&1 | cut -d' ' -f2)
        print_info "Found Python $PYTHON_VERSION"
        return 0
    else
        print_warning "Python not found. Installing Python..."
        install_python
        return $?
    fi
}

# Install Python if needed
install_python() {
    case "$OS" in
        linux)
            if command -v apt-get &> /dev/null; then
                sudo apt-get update
                sudo apt-get install -y python3 python3-pip python3-venv
            elif command -v yum &> /dev/null; then
                sudo yum install -y python3 python3-pip
            elif command -v dnf &> /dev/null; then
                sudo dnf install -y python3 python3-pip
            else
                print_error "Cannot install Python automatically on this Linux distribution."
                print_error "Please install Python 3.8+ manually and rerun this script."
                return 1
            fi
            PYTHON_CMD="python3"
            ;;
        macos)
            if command -v brew &> /dev/null; then
                brew install python3
            else
                print_error "Homebrew not found. Please install Homebrew or Python manually."
                print_error "Visit https://brew.sh to install Homebrew."
                return 1
            fi
            PYTHON_CMD="python3"
            ;;
        windows)
            print_error "Automatic Python installation on Windows is not supported."
            print_error "Please install Python 3.8+ from https://python.org and rerun this script."
            print_error "Note: Use Git Bash or WSL for best experience."
            return 1
            ;;
        *)
            print_error "Unknown OS. Cannot install Python automatically."
            return 1
            ;;
    esac

    # Verify installation
    if command -v "$PYTHON_CMD" &> /dev/null; then
        print_success "Python installed successfully"
        return 0
    else
        print_error "Python installation failed"
        return 1
    fi
}

# Setup directory structure
setup_directories() {
    print_info "Setting up directory structure..."

    local dirs=(
        "work"
        "submissions"
        "submissions/receipts"
        "config"
        "context"
        "tools"
        ".index"
    )

    for dir in "${dirs[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            print_info "Created directory: $dir"
        fi
    done

    # Create placeholder files
    touch submissions/.gitkeep
    touch submissions/.gitignore
    echo "*.json" > submissions/.gitignore
    echo "receipts/" >> submissions/.gitignore

    print_success "Directory structure ready"
}

# Create default config files
create_config_files() {
    print_info "Creating default configuration files..."

    if [ ! -f "config/form_config.json" ]; then
        cat > config/form_config.json << 'EOF'
{
  "google_form_url": "",
  "google_sheet_id": "",
  "field_ids": {
    "exercise_id": "",
    "student_name": "",
    "answer": ""
  }
}
EOF
        print_info "Created config/form_config.json"
    fi

    if [ ! -f "config/form_config.example.json" ]; then
        cat > config/form_config.example.json << 'EOF'
{
  "google_form_url": "https://docs.google.com/forms/d/e/YOUR_FORM_ID/viewform",
  "google_sheet_id": "YOUR_SHEET_ID",
  "field_ids": {
    "exercise_id": "entry.1234567890",
    "student_name": "entry.0987654321",
    "answer": "entry.1111111111"
  }
}
EOF
        print_info "Created config/form_config.example.json"
    fi

    if [ ! -f "BOOTSTRAP.md" ]; then
        cat > BOOTSTRAP.md << 'EOF'
# Student Bootstrap Profile

## Student Name
(To be filled)

## Field of Study
(To be filled)

## Experience with AI Agents
(To be filled)

## Notes
(Any additional notes)
EOF
        print_info "Created BOOTSTRAP.md"
    fi

    if [ ! -f "STARTUP.md" ]; then
        cat > STARTUP.md << 'EOF'
# Startup Status

## Checks
- [ ] Python 3.8+ available
- [ ] Exercise files initialized
- [ ] Course materials indexed

## Notes
EOF
        print_info "Created STARTUP.md"
    fi

    if [ ! -f "INSIGHTS.md" ]; then
        cat > INSIGHTS.md << 'EOF'
# Learning Insights Log

## Session 1
- Exercise: 
- Key insight: 
- Weakness identified: 
- Next action: 
EOF
        print_info "Created INSIGHTS.md"
    fi
}

# Initialize exercise files
initialize_exercises() {
    print_info "Initializing exercise files..."

    if [ -f "tools/init_exercises.py" ]; then
        # Get student name from bootstrap if available
        local student_name=""
        if [ -f "BOOTSTRAP.md" ]; then
            student_name=$(grep -A1 "## Student Name" BOOTSTRAP.md 2>/dev/null | tail -1 | tr -d '# ' || echo "")
        fi

        if [ -n "$student_name" ]; then
            $PYTHON_CMD tools/init_exercises.py --student-name "$student_name"
        else
            $PYTHON_CMD tools/init_exercises.py
        fi
        print_success "Exercise files initialized"
    else
        print_warning "init_exercises.py not found, skipping exercise initialization"
    fi
}

# Run startup checks
run_startup_checks() {
    print_info "Running startup checks..."

    if [ -f "tools/startup_check.py" ]; then
        if $PYTHON_CMD tools/startup_check.py; then
            print_success "Startup checks passed"
            # Mark startup as complete
            if [ -f "STARTUP.md" ]; then
                if ! grep -q "## STARTUP COMPLETE" STARTUP.md; then
                    echo -e "\n## STARTUP COMPLETE" >> STARTUP.md
                    print_info "Marked startup as complete in STARTUP.md"
                fi
            fi
            return 0
        else
            print_warning "Some startup checks failed. You may need to fix issues manually."
            return 1
        fi
    else
        print_warning "startup_check.py not found, skipping checks"
        return 0
    fi
}

# Index course materials
index_course_materials() {
    print_info "Indexing course materials..."

    if [ -f "tools/index_course_materials.py" ]; then
        $PYTHON_CMD tools/index_course_materials.py --source-mode website
        print_success "Course materials indexed"
    else
        print_warning "index_course_materials.py not found, skipping indexing"
    fi
}

# Main installation function
main() {
    print_info "=== TI Student Agent Pack Installer ==="
    print_info "Installing to: $(pwd)"

    detect_os
    check_python

    if [ $? -ne 0 ]; then
        print_error "Python check failed. Please install Python 3.8+ and rerun."
        exit 1
    fi

    setup_directories
    create_config_files
    initialize_exercises
    run_startup_checks
    index_course_materials

    print_success ""
    print_success "=== Installation Complete ==="
    print_success ""
    print_success "Next steps:"
    print_success "1. Edit config/form_config.json with your Google Form details"
    print_success "2. Complete BOOTSTRAP.md with your information"
    print_success "3. Start working on exercises in the work/ directory"
    print_success ""
    print_success "Available commands:"
    print_success "  python tools/submit_exercise.py --from-markdown work/E1.md"
    print_success "  python tools/progress_dashboard.py"
    print_success "  python tools/ask_course.py --q \"Your question here\""
    print_success ""
    print_success "To get help with an exercise, open this folder in your coding agent and"
    print_success "reference the AGENTS.md file for coaching instructions."
    print_success ""
}

# Run main function
main
