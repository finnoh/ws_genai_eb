#!/usr/bin/env bash
# TI Student Agent Pack Installer
# Quick install: curl -sL https://raw.githubusercontent.com/finnoh/ti-student-agent-pack/main/install.sh | bash
# Or download the zip and run: chmod +x install.sh && ./install.sh

set -euo pipefail

echo "=== TI Student Agent Pack Installer ==="

# Find and extract the zip file
ZIP_FILE=""
if [ -f "student-agent-pack.zip" ]; then
    ZIP_FILE="student-agent-pack.zip"
elif [ -f "ti-student-agent-pack.zip" ]; then
    ZIP_FILE="ti-student-agent-pack.zip"
elif [ -f "ti-student-agent-pack-latest.zip" ]; then
    ZIP_FILE="ti-student-agent-pack-latest.zip"
else
    # Look for any .zip file in the current directory
    for f in *.zip; do
        if [ -f "$f" ]; then
            ZIP_FILE="$f"
            break
        fi
    done
fi

if [ -n "$ZIP_FILE" ]; then
    echo "Extracting $ZIP_FILE..."
    unzip -q "$ZIP_FILE"
elif [ -d "student-agent-pack" ]; then
    echo "Using existing student-agent-pack directory..."
else
    echo "Error: Could not find student-agent-pack directory or zip file"
    echo "Please download the zip file first or ensure you're in the correct directory"
    exit 1
fi

# Run the actual install script
if [ -f "student-agent-pack/install.sh" ]; then
    cd student-agent-pack
    ./install.sh
else
    echo "Error: install.sh not found in student-agent-pack"
    exit 1
fi
