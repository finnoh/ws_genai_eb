# TI Student Agent Pack

Portable, self-contained workspace for Tinbergen Institute workshop exercises.

## Quick Start

### Option 1: Download and Install
1. Download the zip file
2. Extract it
3. Run the installer: `chmod +x install.sh && ./install.sh`

### Option 2: One-line Install (Linux/macOS)
```bash
curl -sL https://raw.githubusercontent.com/finnoh/ti-student-agent-pack/main/install.sh | bash
```

## What's Inside
- Exercise work files (E1-E8)
- Submission tools
- Course coaching agent (AGENTS.md)
- Progress dashboard
- Course Q&A tool

## Next Steps
1. Edit `config/form_config.json` with your Google Form details
2. Complete `BOOTSTRAP.md` with your information
3. Start working on exercises in the `work/` directory

## Documentation
- Full documentation: `student-agent-pack/README.md`
- Coaching guide: `student-agent-pack/AGENTS.md`
