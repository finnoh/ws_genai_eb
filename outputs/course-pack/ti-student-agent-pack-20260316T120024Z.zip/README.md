# TI Student Agent Pack

Portable, self-contained workspace for Tinbergen Institute workshop exercises.

## Quick Start

### Option 1: One-line Install (Linux/macOS/Git Bash)

```bash
curl -sL https://raw.githubusercontent.com/finnoh/ti-student-agent-pack/main/install.sh | bash
```

### Option 2: Manual Installation

1. Download the zip file
2. Extract it
3. Run the installer:
   ```bash
   chmod +x install.sh
   ./install.sh
   ```

## What's Included

- Exercise files (E1-E8)
- Submission tools
- TIA coaching agent (AGENTS.md)
- Progress dashboard
- Course Q&A tool

## Next Steps

1. Open the `student-agent-pack/` folder in your coding agent
2. Edit `config/form_config.json` with your Google Form details
3. Complete `BOOTSTRAP.md` with your information
4. Start working on exercises in the `work/` directory

## More Information

- Full documentation: See `AGENTS.md`
- ASCII art: See `TIA-ascii-art.txt`
